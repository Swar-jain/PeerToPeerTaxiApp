package cse512

import org.apache.spark.sql.SparkSession
import scala.math.sqrt
import scala.math.pow

object SpatialQuery extends App{
    def ST_Contains(queryRectangle:String, pointString:String): Boolean = {
        if (queryRectangle == null || queryRectangle.isEmpty() || pointString == null || pointString.isEmpty())
            return false

	val point:Array[Double] = pointString.split(",").map(_.trim.toDouble)
	val rectangle:Array[Double]= queryRectangle.split(",").map(_.trim.toDouble)
  
	var min_x:Double = Math.min(rectangle(0), rectangle(2))
	var max_x:Double = Math.max(rectangle(0), rectangle(2))
	var min_y:Double = Math.min(rectangle(1), rectangle(3))
	var max_y:Double = Math.max(rectangle(1), rectangle(3))

    	return point(0) >= min_x && point(0) <= max_x && point(1) >= min_y && point(1) <= max_y
      	
    }

    def ST_Within(pointString1:String, pointString2:String, distance:Double): Boolean = {
        if (pointString1 == null || pointString1.isEmpty() || pointString2 == null || pointString2.isEmpty() || distance <= 0.00)
            return false

        var n1 = pointString1.split(",")
        var x1 = n1(0).toDouble
        var y1 = n1(1).toDouble
        var n2 = pointString2.split(",")
        var x2 = n2(0).toDouble
        var y2 = n2(1).toDouble
        var d = math.sqrt(math.pow((x2-x1),2) + math.pow((y2-y1), 2))
        if (d <= distance) {
          return true
        }
        else{
          return false
        }
    }

    def runRangeQuery(spark: SparkSession, arg1: String, arg2: String): Long = {

        val pointDf = spark.read.format("com.databricks.spark.csv").option("delimiter","\t").option("header","false").load(arg1);
        pointDf.createOrReplaceTempView("point")

        // YOU NEED TO FILL IN THIS USER DEFINED FUNCTION
        spark.udf.register("ST_Contains",(queryRectangle:String, pointString:String)=> {
            ST_Contains(queryRectangle, pointString)
        })

        val resultDf = spark.sql("select * from point where ST_Contains('"+arg2+"',point._c0)")
        resultDf.show()

        return resultDf.count()
    }

    def runRangeJoinQuery(spark: SparkSession, arg1: String, arg2: String): Long = {

        val pointDf = spark.read.format("com.databricks.spark.csv").option("delimiter","\t").option("header","false").load(arg1);
        pointDf.createOrReplaceTempView("point")

        val rectangleDf = spark.read.format("com.databricks.spark.csv").option("delimiter","\t").option("header","false").load(arg2);
        rectangleDf.createOrReplaceTempView("rectangle")

        // YOU NEED TO FILL IN THIS USER DEFINED FUNCTION
        spark.udf.register("ST_Contains",(queryRectangle:String, pointString:String)=>{
            ST_Contains(queryRectangle, pointString)
        })

        val resultDf = spark.sql("select * from rectangle,point where ST_Contains(rectangle._c0,point._c0)")
        resultDf.show()

        return resultDf.count()
    }

    def runDistanceQuery(spark: SparkSession, arg1: String, arg2: String, arg3: String): Long = {

        val pointDf = spark.read.format("com.databricks.spark.csv").option("delimiter","\t").option("header","false").load(arg1);
        pointDf.createOrReplaceTempView("point")

        // YOU NEED TO FILL IN THIS USER DEFINED FUNCTION
        spark.udf.register("ST_Within",(pointString1:String, pointString2:String, distance:Double)=>{
            ST_Within(pointString1, pointString2, distance)
        })

        val resultDf = spark.sql("select * from point where ST_Within(point._c0,'"+arg2+"',"+arg3+")")
        resultDf.show()

        return resultDf.count()
    }

    def runDistanceJoinQuery(spark: SparkSession, arg1: String, arg2: String, arg3: String): Long = {

        val pointDf = spark.read.format("com.databricks.spark.csv").option("delimiter","\t").option("header","false").load(arg1);
        pointDf.createOrReplaceTempView("point1")

        val pointDf2 = spark.read.format("com.databricks.spark.csv").option("delimiter","\t").option("header","false").load(arg2);
        pointDf2.createOrReplaceTempView("point2")

        // YOU NEED TO FILL IN THIS USER DEFINED FUNCTION
        spark.udf.register("ST_Within",(pointString1:String, pointString2:String, distance:Double)=>{
            ST_Within(pointString1, pointString2, distance)
        })

        val resultDf = spark.sql("select * from point1 p1, point2 p2 where ST_Within(p1._c0, p2._c0, "+arg3+")")
        resultDf.show()

        return resultDf.count()
    }
}
